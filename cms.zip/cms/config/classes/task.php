<?php
/**************************************************************************
 *  Code @  *  Developed by Faiz Kalodi
 *  Purpose: For all operations
 *  (c) All Rights Reserved 
 *  Last Updated on 07 April 2020
 *************************************************************************/
class task extends tableObject{

	function task()
	{
		$this->reset('task', 'id', 'title,details,estimated_time,used_time,alloted_to,alloted_by,alloted_date,priority,status,order,time');
	}
#
}
?>
