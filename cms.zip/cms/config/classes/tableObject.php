<?php 
/* ************************************************************************
 *  Code @Faiz Kalodi
 *  Project: Task Scheduler
 *  Purpose : Main class tableObject 
 *  (c) All Rights Reserved
 *  Last Updated on 10 April 2020
 **************************************************************************/
class tableObject
{
 	var $key 		= array(),
		$value 		= array(),
		$page 		= array(),
		$mem 		= array(),
		$table 		= false,
		$status 	= 'off',
		$condition 	= false;

# Loads the Current Record as per condition to the database 

 	function reset($_tableName, $_key, $_value)
	{
		global $App;
		# Initialize Object

		$this->table = $App->mySql['PREFIX'].$_tableName;
		$_key = explode(",", $_key);
		foreach($_key as $k)
		{
	  		$this->key[$k] = false;
	  		$this->value[$k] = false;
		}
		$_value = explode(",", $_value);
		foreach($_value as $k)
		{
	  		$this->value[$k] = false;
		}
		putenv("TZ=Asia/Dubai");
	# Paging Info
    	$this->page['TOTAL_RECORDS'] = 0;
		$this->page['FIRST_RECORD'] = 0;
		$this->page['RECORD_NO'] = 0;
		$this->page['SIZE'] = 0;
		$this->page['CURRENT'] = 0;
		$this->page['TOTAL'] = 0;
		$this->page['CONDITION'] = 1;
		$this->page['GROUP'] = '';
		$this->page['ORDER'] = '';
		$this->page['HANDLE'] = '';

		return true;
	}
# Loads the Current Record as per condition to the database
 	function select()
	{
		$this->getCondition();
		$db = "SELECT * FROM `{$this->table}` WHERE ({$this->condition})  LIMIT 1;";//AND `upto` > 'NOW()'
		$_t = mysql_query($db);
		if($_t = @mysql_fetch_assoc($_t))
		{
	  		foreach($this->value as $k => $v)
			{
				$this->value[$k] = html_entity_decode($_t[$k]);
			}
	  		return $this->onSelect();
		}
		return false;
 	}
 	# Function for encryption and decryption
	# coaded by Faiz 
  
 	function rotate($chrI)
	{
		$no_of_times_to_rotate_a_char = strlen("abcd");
		return chr((ord($chrI) + $no_of_times_to_rotate_a_char) % 256);
 	}

 	function rerotate($chrI)
	{
		$no_of_times_to_rotate_a_char = strlen("abcd");
		return chr((ord($chrI) - $no_of_times_to_rotate_a_char) % 256);
 	}

  function showBanner($page_name = false)
	{
		global $App;
		$App->setup(false,"banner",false);
		$page_name  = $this->curPageName();
		$banner		= new banner;
		$sql = "SELECT * FROM `{$banner->table}` WHERE(`page` = '{$page_name}') AND `status`= '1' ";//die($sql);
		$res = mysql_query($sql)or die(mysql_error());
		$nr  = mysql_num_rows($res);
		if($nr > 0)
		{
			while($row = mysql_fetch_array($res))
			{
				$page_banner = $App->data("banner/".$row['banner'],false);
				$page_title  =  $row['title'];
// onclick="window.location='index.php' style="cursor:pointer" alt="HOME PAGE" title="HOME PAGE"
				echo "<img src=\"{$page_banner}\" width='250' height='188' style='border:solid 1px; border-color:#CCCCCC;padding:5px;cursor:pointer' alt='Click on me to return to the Home Page' title='Click on me to return to the Home Page' onclick='window.location=\"index.php\"'  /><br>";
			}
		}
		else
		{
echo '<img src="images/apple_banner.png" width="250" height="188" border= "1" style="cursor:pointer" onclick="window.location=\'index.php\'" alt="Click on me to return to the Home Page" title="Click on me to return to the Home Page"  /><br> <div align="center"><a href="index.php" style="color:#000000; font-size:11px; font-style:italic;" ><u>Click on me to return to the Home Page</u></a></div>';
		
		}
		

	
	
	}

#
   
	#The argument $time_ago is in timestamp (Y-m-d H:i:s)format.	
	function timeAgo($time_ago)
	{
		$time_ago = strtotime($time_ago);
		$cur_time   = time();
		$time_elapsed   = $cur_time - $time_ago;
		$seconds    = $time_elapsed ;
		$minutes    = round($time_elapsed / 60 );
		$hours      = round($time_elapsed / 3600);
		$days       = round($time_elapsed / 86400 );
		$weeks      = round($time_elapsed / 604800);
		$months     = round($time_elapsed / 2600640 );
		$years      = round($time_elapsed / 31207680 );
		// Seconds
		if($seconds <= 60){
			return "just now";
		}
		//Minutes
		else if($minutes <=60){
			if($minutes==1){
				return "one minute ago";
			}
			else{
				return "$minutes minutes ago";
			}
		}
		//Hours
		else if($hours <=24){
			if($hours==1){
				return "an hour ago";
			}else{
				return "$hours hrs ago";
			}
		}
		//Days
		else if($days <= 7){
			if($days==1){
				return "yesterday";
			}else{
				return "$days days ago";
			}
		}
		//Weeks
		else if($weeks <= 4.3){
			if($weeks==1){
				return "a week ago";
			}else{
				return "$weeks weeks ago";
			}
		}
		//Months
		else if($months <=12){
			if($months==1){
				return "a month ago";
			}else{
				return "$months months ago";
			}
		}
		//Years
		else{
			if($years==1){
				return "one year ago";
			}else{
				return "$years years ago";
			}
		}
	}
	
# encrypt or decrypt ids
 	function encryptValue($strI)
	{
		$strI = $strI."Clay";
		$strO = "";
		for($i = 0; $i < (strlen($strI))  ; $i=$i+6)
		{
			if(($i + 3) < strlen($strI))
			{
				$a = $strI{$i};
				$strI{$i} =  $strI{$i + 3};
				$strI{$i + 3} = $a;
			}
			if(($i + 4) < strlen($strI))
			{
				$a = $strI{$i+1};
				$strI{$i+1} =  $strI{$i + 4};
				$strI{$i + 4} = $a;
			}
			if(($i + 5) < strlen($strI))
			{
				$a = $strI{$i+2}; 
				$strI{$i+2} =  $strI{$i + 5};
				$strI{$i + 5} = $a;
			}
		}
		for($i = 0; $i < strlen($strI); $i++)	
		{
			$strO .= $this->rotate($strI{$i});
		}
	
		return urlencode($strO);
 	}

	function decryptValue($strI){
	$strO = "";
	$strI = urldecode($strI);
	for($i = 0; $i < strlen($strI); $i++){
		$strO .= $this->rerotate($strI{$i});
	}
	for($i = 0; $i < (strlen($strO))  ; $i=$i+6){
		if(($i + 3) < strlen($strO)){
			$a = $strO{$i};
			$strO{$i} =  $strO{$i + 3};
			$strO{$i + 3} = $a;
		}
		if(($i + 4) < strlen($strO)){
			$a = $strO{$i+1};
			$strO{$i+1} =  $strO{$i + 4};
			$strO{$i + 4} = $a;
		}
		if(($i + 5) < strlen($strO)){
			$a = $strO{$i+2};
			$strO{$i+2} =  $strO{$i + 5};
			$strO{$i + 5} = $a;
		}
	}
	$strO = str_replace("Clay","",$strO);
	return $strO;
 }
 //end

# Deletes the Record as per condition from the database
 	function delete()
	{
		global $App;
		$this->getCondition();
		$_t = mysql_query("DELETE FROM `{$this->table}` WHERE ({$this->condition}) LIMIT 1;");
		
		$App->log("Deleted data from `{$this->table}` ");
		
		if(mysql_affected_rows($App->mySql['CONNECTION']) == 1)
		{
	  		return true;
		}
		return false;
 	}
# Insert Data to the Database
 	function insert()
	{
		global $App;
		$_sql = "INSERT INTO `{$this->table}` SET ".$this->saveThis(true); //die ($_sql);
		$_sql = mysql_query($_sql)or die(mysql_error());
		if(mysql_affected_rows($App->mySql['CONNECTION']) == 1)
		{		
			$App->log("Inserted data into `{$this->table}` ");
	  		return true;
		}
		return false;
	}

# Update Data to the Database
 	function update()
	{
    	global $App;
		$this->getCondition();
		$_sql = "UPDATE `{$this->table}` SET ".$this->saveThis(true)." WHERE ({$this->condition}) LIMIT 1;";//die($_sql);
		$_sql = mysql_query($_sql)or die(mysql_error());
		if(mysql_affected_rows($App->mySql['CONNECTION']) == 1)
		{
			$updt_id = $this->value['id'];
	  		$App->log("Updated ID:`{$updt_id}` in `{$this->table}` ");
			return true;
		}
		return false;
 	}

	
	#image resize
	function imageResize($width, $height, $target) 
	{
		if ($width > $height) 
		{
			$percentage = ($target / $width);
		} 
		else 
		{
			$percentage = ($target / $height);
		}
		
		//gets the new value and applies the percentage, then rounds the value
		$width = round($width * $percentage);
		$height = round($height * $percentage);
		
		return "width=\"$width\" height=\"$height\"";
		
	} 

/* Getting the time, if greater than 24, will convert to corresponding time */
function getRealTime($time)
{
	if($time > 24)
	{
		$time = $time - 24;
	}
	else
	{
		$time = $time;
	}
	
	return $time;

}

/*Getting Randome Time*/
function getRandTime($time1,$time2)//23,4
{
	//time1 < time2
	if($time1 < $time2)
	{
		$tm_str = "";
		for ($i=$time1; $i<$time2; $i++)
		{
			$tm_str .= $i.',';
		
		}
		$tm_str .= $time2;
	}

	//if time1 > $time2
	if($time1 > $time2)
	{
		$tm_str = "";
		for ($j=$time1; $j<=24; $j++)
		{
			$tm_str .= $j.',';
		}
		for($k=1; $k<$time2;$k++)
		{
			$tm_str .= $k.',';
		}
		$tm_str .= $time2;
	}

	$array = explode(",",$tm_str);
	$targetArray = $array;
	$rand = array_rand($targetArray);

 return ($targetArray[$rand]);

}

/* Display 12 hr time dropdpwn menu */	
function getTimeHours($time)
{
	switch($time)
	{
	  	case '1' : $tm = '1 AM'; break;
		case '2' : $tm = '2 AM'; break;
		case '3' : $tm = '3 AM'; break;
		case '4' : $tm = '4 AM'; break;
		case '5' : $tm = '5 AM'; break;
		case '6' : $tm = '6 AM'; break;
		case '7' : $tm = '7 AM'; break;
		case '8' : $tm = '8 AM'; break;
		case '9' : $tm = '9 AM'; break;
		case '10' : $tm = '10 AM'; break;
		case '11' : $tm = '11 AM'; break;
		case '12' : $tm = '12 PM'; break;
		case '13' : $tm = '1 PM'; break;
		case '14' : $tm = '2 PM'; break;
		case '15' : $tm = '3 PM'; break;
		case '16' : $tm = '4 PM'; break;
		case '17' : $tm = '5 PM'; break;
		case '18' : $tm = '6 PM'; break;
		case '19' : $tm = '7 PM'; break;
		case '20' : $tm = '8 PM'; break;
		case '21' : $tm = '9 PM'; break;
		case '22' : $tm = '10 PM'; break;
		case '23' : $tm = '11 PM'; break;
		case '24' : $tm = '12 AM'; break;

	}

	return $tm;

}
	
# Loads the SQL Condition to return the Current key Row to $this->condition
 	function getCondition()
	{
	$this->condition = '';
		foreach($this->key as $k => $v)
		{
			//$v = htmlspecialchars($v);
			if($this->condition == '')
			{
				$this->condition .= "`{$k}` = '{$v}' ";
			}
			else
			{
				$this->condition .= "AND `{$k}` = '{$v}'";
			}
		}
		return true;
 	}
# Perform any Decryption Operations [if Any] on the record from Database before using
 	function onSelect()
	{ 
		return true;
	}
# Perform any Encryption Operations [if Any] on the record from Database before using
 	function saveThis($insert = true)
	{
 		putenv("TZ=Asia/Dubai");
		$_value = '';
		foreach($this->value as $k => $v)
		{
	  		if($k == 'time')
			{ 
				continue;
			}
			
			//$v	=	strip_tags($v,'<br><img>');
	   		//$v 	= 	htmlspecialchars($v);
			$v	=	trim($v);
			//$v = mysql_real_escape_string($v);
	 		// $v =  htmlentities($v);
	  		$v = htmlspecialchars(str_replace("'", '&#39;', $v));
			//$v = htmlspecialchars(str_replace("<", '&nbsp;', html_entity_decode($v)));
			//$v = htmlspecialchars(str_replace(">", '&nbsp;', html_entity_decode($v)));
			$v = htmlspecialchars(str_replace("<script", '&nbsp;', html_entity_decode($v)));
			//$v = htmlspecialchars(str_replace("<style", '&nbsp;', html_entity_decode($v)));
			$v = htmlspecialchars(str_replace("<noframes", '&nbsp;', html_entity_decode($v)));
			$v = htmlspecialchars(str_replace("<select", '&nbsp;', html_entity_decode($v)));
			$v = htmlspecialchars(str_replace("<option", '&nbsp;', html_entity_decode($v)));
			$v = htmlspecialchars(str_replace("<iframe", '&nbsp;', html_entity_decode($v)));
			$v = htmlspecialchars(str_replace("<input", '&nbsp;', html_entity_decode($v)));
	  		$_value .= (($_value == '')? "`{$k}` = '{$v}'" :", `{$k}` = '{$v}'");
		}
		
		// get timezone
		$tm = date("Y-m-d H:i:s");
		$_value .= ", `time` = '".$tm."'";
		//die( $_value );
		return $_value;
	}
# Find theID for next new record
 	function nextID($key = 'id')
	{
		$_sql = "SELECT MAX(`{$key}`) + 1 as `next` FROM `{$this->table}` LIMIT 1;";//die($_sql);
		$_sql = mysql_fetch_assoc(mysql_query($_sql));
		$_sql = $_sql['next'];
		if($_sql > 0)
		{
	  		return $_sql;
		}
		return 1;
 	}
# Turn on the specified record for a particular number of days
 	function turnOn($days = false)
	{
		global $App;
		$this->getCondition();
		if($days)
		{
			$db = "UPDATE `{$this->table}` SET `upto` = DATE_ADD(NOW(), INTERVAL '{$days}' DAY), `time` = NOW() WHERE ({$this->condition}) LIMIT 1;";
		}
		else
		{
			$db = "UPDATE `{$this->table}` SET `upto` = '9999-12-31', `time` = NOW() WHERE ({$this->condition}) LIMIT 1;";
		}
		$db = mysql_query($db);
		if(mysql_affected_rows($App->mySql['CONNECTION']) == 1)
		{
	  		return true;
		}
		return false;
 	}
# Turn off the specified record 
 	function turnOff()
	{
		global $App;
		$this->getCondition();
		$db[0] = "UPDATE `{$this->table}` SET";
		$db[1] = "`upto` = DATE_SUB(NOW(), INTERVAL '1' DAY), `time` = NOW() WHERE ({$this->condition}) LIMIT 1;";
		$db = $App->sql($db[0], $db[1], false);
		if(mysql_affected_rows($App->mySql['CONNECTION']) == 1)
		{
	  		return true;
		}
		return false;
 	}
# Read with Paging
 	function startPaging($pageSize = 20)
	{
		global $App;
		
		if((int)$_POST['SP_NO'] < 1)		
		$_POST['SP_NO']	=	1;
		
		$this->page['SIZE'] = $pageSize;
		if(empty($_POST['SP_CN']))
		{
	  		#=->
		}
		else
		{
	  		$this->page['CONDITION'] = stripslashes($_POST['SP_CN']);
	  		//foreach($_POST as $k => $v){ $this->mem[$k] = stripslashes($v);}
	  		foreach($_POST as $k => $v)
			{ 	
				$this->mem[$k] = html_entity_decode($v);
			}
		}
		# Count it!

  		$db1 = @mysql_fetch_assoc(mysql_query("SELECT COUNT(*) as `total` FROM `{$this->table}` WHERE({$this->page['CONDITION']});"));
		# Collect Paging Info!
    	$this->page['TOTAL_RECORDS'] = $db1['total'];
		$this->page['CURRENT'] = empty($_POST['SP_NO']) ? 1 : $_POST['SP_NO'];
		$this->page['TOTAL'] = ceil($this->page['TOTAL_RECORDS'] / $this->page['SIZE']);
		$this->page['RECORD_NO'] = $this->page['FIRST_RECORD'] = ($this->page['CURRENT'] - 1) * $this->page['SIZE'];
    	#Now Read it!
    	$fields = "";
		foreach($this->key as $k => $v)
		{
	  		$fields .= (($fields == "") ? "`$k`" : ", `$k`" );
		}

		//die($this->page['CONDITION']);

		$db = "SELECT {$fields} FROM `{$this->table}`";
		$db.= "WHERE ({$this->page['CONDITION']})"; 
		$db.= empty($this->page['GROUP'])? "" : " GROUP BY {$this->page['GROUP']}";
		$db.= empty($this->page['ORDER'])? "" : " ORDER BY {$this->page['ORDER']}";
		$db.= " LIMIT {$this->page['FIRST_RECORD']}, {$this->page['SIZE']};";
		//die($db);
		$this->page['HANDLE'] = mysql_query($db);
		return mysql_num_rows($this->page['HANDLE']);
 	}
	
	#Read next Possible record in the page
 	function nextRecord()
	{
		if($r = mysql_fetch_assoc($this->page['HANDLE']))
		{
	  		foreach($this->key as $k => $v)
			{
	   			$this->key[$k] = $r[$k];
	  		}
	  		if($this->select())
			{
				return ++$this->page['RECORD_NO'];
	  		}
		}
		return false;
 	}
# Check if a record with a specified field exists
 	function Exists($key, $value)
	{
	
		$sql = "SELECT `{$key}` FROM `{$this->table}` WHERE(`{$key}` LIKE '{$value}') LIMIT 1;"; //die($sql);
		if(mysql_fetch_assoc(mysql_query($sql)))
		{
	  		return true;
		}
		return false;
 	} 
	
	


 #check email duplication
 
 	function emailDuplicate($email,$id = false)
	{
		if($id)
		{
			$db	 	= "SELECT `email` FROM `{$this->table}` WHERE `email` = '{$email}' AND `id` <> '{$id}'";
			//die ($db);
		}
		else
		{
			$db	 	= "SELECT `email` FROM `{$this->table}` WHERE `email` = '{$email}'";
			//die ($db);
		}
		$query	= mysql_query($db);
		if(mysql_num_rows($query) > 0)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
 
	
 #get file extension	
	function getExtension($filename) 
 	{ 
 	$filename = strtolower($filename) ; 
 	$exts = split("[/\\.]", $filename) ; 
 	$n = count($exts)-1; 
 	$exts = $exts[$n]; 
 	return $exts; 
 	}  

 
# Show Page Controls
 	function pagingControls($txtCss = false, $btnCss = false, $fontCss = false)
	{
		global $App;
		if($this->page['TOTAL'] < 2)
		{
	  		$code .= "<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" height=\"25\" style=\"text-align:center;\" align=\"center\" class=\"{$fontCss}\"><tr><td>Showing Page <b>[1]</b> of <b>[1]</b></td></tr></table>";
		}
		#=->
		$btnCss = "pagination1";
		//die($txtCss);

		if($txtCss){ $txtCss = "class=\"{$txtCss}\"";}
		if($btnCss){ $btnCss = "class=\"{$btnCss}\"";}
		if($fontCss){ $fontCss = "class=\"{$fontCss}\"";}
		//die($txtCss);
		#=->
		$code .= "<form action=\"\" method=\"post\" enctype=\"application/x-www-form-urlencoded\" name=\"SP_form\" id=\"SP_form\" target=\"_self\">
			 <table class='news-pagination' style=\"border:none;background-color:transparent;\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\"  align=\"center\" {$fontCss}>
			 <tr>";
		#=->
		//$code .= "<td>&nbsp;Showing &nbsp;</td>";

		if($this->page['FIRST_RECORD'] == 0)
		{
			// $code .= "<td><input id=\"btnPrevious\" name=\"\" type=\"image\" src=".$App->data('pagination/left.png', false)." value=\"Previous\" alt='Previous' title= 'Previous' {$btnCss} />&nbsp;</td>";
			$code .= "<td><span class='page-left disable'><span>Previous</span></span></td>";
		}
		else
		{
			//$code .= "<td><input id=\"btnPrevious\" name=\"\" type=\"submit\"  value=\"&#10096;\" onclick=\"return sespaging.goTo(0);\" {$btnCss} alt='Previous' title= 'Previous' /></td>";
			$code .= "<td><input id=\"btnPrevious\" name=\"\" type=\"submit\"  value=\"Previous\" onclick=\"return sespaging.goTo(0);\" {$btnCss} alt='Previous' title= 'Previous' /></td>";
		}

		$code .= "<td  $txtCss > Page ".($this->page['CURRENT'])." of {$this->page['TOTAL']}</td>";

		if(($this->page['RECORD_NO']) == $this->page['TOTAL_RECORDS'])
		{
			//$code .= "<td><input id=\"btnNext\" name=\"\" type=\"image\" src=".$App->data('img/pagination/right.png', false)." value=\"Next\" alt='Next' title= 'Next'  {$btnCss} /></td>";
			$code .= "<td><span class='page-right disable'><span>Next</span></span></td>";
		}
		else
		{
			// $code .= "<td><input id=\"btnNext\" name=\"\" type=\"submit\" value=\"&#10097;\" onclick=\"return sespaging.goTo(2);\" {$btnCss} alt='Next' title= 'Next' /></td>";
			$code .= "<td><span class='page-right'><input id=\"btnNext\" name=\"\" type=\"submit\" value=\"Next\" onclick=\"return sespaging.goTo(2);\" {$btnCss} alt='Next' title= 'Next' /></span></td>";
		}

		
		$code .= "<td><input id=\"SP_NO\" name=\"SP_NO\" type=\"hidden\" size=\"4\" {$txtCss} value=\"{$this->page['CURRENT']}\" style=\"text-align:center;\" /></td>";
		
		
		#=->
		$code .= "</tr></table>";
		$code .= "<input name=\"SP_CN\" id=\"SP_CN\" type=\"hidden\" value=\"{$this->page['CONDITION']}\" />";
		foreach($this->mem as $k => $v)
		{
	  		$code .= "<input name=\"[mem][{$k}]\" id=\"[mem][{$k}]\" type=\"hidden\" value=\"{$v}\" />";
		}
		$code .= "</form>";
		return $code;
 	}
	
	#  Random String
function genRandomString($length = 12) {
    $characters = "0123456789abcdefghijklmnopqrstuvwxyz";
    $string ="";    

    for ($p = 0; $p < $length; $p++) {
        $string.= $characters[mt_rand(0, strlen($characters))];
    }

    return $string;
}

#  Get field value 
function getVal($id, $field	= 'value') // Allowed time between two views, for earnings calculation, in seconds
	{
		if(!is_numeric($id) or $id <= 0 )
		return false;
		$db	 	= 	"SELECT `$field` as `value`  FROM `{$this->table}` WHERE `id` = $id limit 1";
		$query	= 	mysql_query($db);
		if(!$query or !mysql_num_rows($query))		
		return false;
		$row	=	mysql_fetch_assoc($query);
		return	html_entity_decode($row['value']);
	}
	
# ID Encode
function idEncode($id)
{
	return $this->strToHex(base64_encode($id));
}	

# ID Decode
function idDecode($id)
{
	return base64_decode($this->hexToStr($id));
}
	
#  String to Hex Encode
function strToHex($string)
	{
    	$hex='';
    	for ($i=0; $i < strlen($string); $i++)
    		{
       			 $hex .= dechex(ord($string[$i]));
    		}
    	return $hex;
	}
#  Hex to String Decode
function hexToStr($hex)
	{
		$string='';
		for ($i=0; $i < strlen($hex)-1; $i+=2)
			{
				$string .= chr(hexdec($hex[$i].$hex[$i+1]));
			}
		return $string;
	}

#  Split Sentence by space
function split_sentence($str,$count)
	{
	  if(strlen($str)>$count)
	  {
	   //echo $str."<br/>";
	   
	   $str_content = substr($str, 0, $count);
	   //echo $str_content;
	   $str_pos = strrpos($str_content, " ");
	  // echo $str_pos;
	   if ($str_pos>0)
		{
		  $str_content = substr($str_content, 0, $str_pos);
		  return $str_content."..."; 
		} 
		else
		{
		   return $str_content."...";
		}
	   }
	   else
	   {
		return $str;
	   }	
	}

#  Show formated date time
function showDate($dateTime = '', $format = "D, d-m-Y")
{
	if(empty($dateTime))
	$dateTime	=	date('Y-m-d');
	$dateTime	=	strtotime($dateTime);
	return date($format,$dateTime);
}

#  Show formated date time
function showDateTime($dateTime = '', $format = "D, d M Y h:i A")
{
	if(empty($dateTime))
	$dateTime	=	date('Y-m-d');
	$dateTime	=	strtotime($dateTime);
	return date($format,$dateTime);
}

#Current Page URL
function curPageURL() 
{
	 $pageURL = 'http';
	 if ($_SERVER["HTTPS"] == "on") {$pageURL .= "s";}
	 $pageURL .= "://";
	 if ($_SERVER["SERVER_PORT"] != "80") {
	  $pageURL .= $_SERVER["SERVER_NAME"].":".$_SERVER["SERVER_PORT"].$_SERVER["REQUEST_URI"];
	 } else {
	  $pageURL .= $_SERVER["SERVER_NAME"].$_SERVER["REQUEST_URI"];
	 }
	 return $pageURL;
}

#Current Page Name
function curPageName()
{
 return substr($_SERVER["SCRIPT_NAME"],strrpos($_SERVER["SCRIPT_NAME"],"/")+1);
}

#validate url
function validateURL($url)
{
		return (preg_match("#^https?://.+#", $url) and @fopen($url,"r"))?true:false;
	}
	
#validate email
function validateEmail($email) 
{
	return (eregi("^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$", $email))?true:false;	
}	

#Getting the number of given month
function getMonthNum($month)
{
	switch($month)
	{
		case 'Jan': return(1);break;
		case 'January': return(1);break;
		case 'Feb': return(2);break;
		case 'February': return(2);break;
		case 'Mar': return(3);break;
		case 'March': return(3);break;
		case 'Apr': return(4);break;
		case 'April': return(4);break;
		case 'May': return(5);break;
		case 'Jun': return(6);break;
		case 'June': return(6);break;
		case 'Jul': return(7);break;
		case 'July': return(7);break;
		case 'Aug': return(8);break;
		case 'August': return(8);break;
		case 'Sep': return(9);break;
		case 'September': return(9);break;
		case 'Oct': return(10);break;
		case 'October': return(10);break;
		case 'Nov': return(11);break;
		case 'November': return(11);break;
		case 'Dec': return(12);break;
		case 'December': return(12);break;

	}
} 

#validate date
function is_date( $str )
{
  $stamp = strtotime( $str );
 
  if (!is_numeric($stamp))
  {
     return false;
  }
  $month = date( 'm', $stamp );
  $day   = date( 'd', $stamp );
  $year  = date( 'Y', $stamp );
 
  if (checkdate($month, $day, $year))
  {
     return true;
  }
 
  return false;
} 
#
#Geltting Gold silver  and Bronze values with given points
function getConis($point,$coin)
{
		if($point >= 10000)
		{
			$g 		 = $point / 10000;
			$g  	 =  number_format($g,4,'.', '');
			$gres 	 = explode('.',$g);
			$gold	 = $gres[0];
		
		
			$silv	 = 	$gres[1] / 100;
			$silv  	 =  number_format($silv,2,'.', '');
			$sres 	 = 	explode('.',$silv);
			$silver  =	$sres[0];
			$bronze  =  $sres[1];
		
		
		}
		
		if($point >= 100 and $point <10000)
		{
			$silv	 =  $point / 100;
			$silv  	 =  number_format($silv,2,'.', '');
			$sres 	 = 	explode('.',$silv);
			$gold 	 =  0;
			$silver  =	$sres[0];
			$bronze  =  $sres[1];	
		}
		
		if($point < 100)
		{
			$gold 		= 0;
			$silver 	= 0;
			$bronze  	=  $point;	
		}


		if($coin == '1')
		{
			return $gold;
		}
	
		else if($coin == '2')
		{
			return $silver;
		}
		if($coin == '3')
		{
			return $bronze;
		}


}
#End Points calculations

/* GETTING lEVEL FROM THE POINT */
function getUserLevel($point)
{
	if($point <= 0)
	{
		$level = 0;

	}
	else if($point > 0 and  $point <= 1000)
	{
		$level = $point/100;
	}

	else if($point > 1000 and  $point <= 3000)
	{
		$level = ($point/200)+ 5;
	}
	else if($point > 3000 and  $point <= 6000)
	{
		$level = ($point/300)+ 10;
	}

	else if($point > 6000 and  $point <= 10000)
	{
		$level = ($point/400)+ 15;
	}

	else if($point > 10000 and  $point <= 15000)
	{
		$level = ($point/500)+ 20;
	}

	else if($point > 15000 and  $point <= 21000)
	{
		$level = ($point/600)+ 25;
	}

	else if($point > 21000 and  $point <= 28000)
	{
		$level = ($point/700)+ 30;
	}

	else if($point > 28000 and  $point <= 36000)
	{
		$level = ($point/800)+ 35;
	}

	else if($point > 36000 and  $point <= 45000)
	{
		$level = ($point/900)+ 40;
	}

	else if($point > 45000 and  $point <55000)
	{
		$level = ($point/1000)+ 45;
	}
	else if($point >= 55000)
	{
				$level = 100;
	}

	return intval($level);

}
#End

/* Getting Level progress */
function levelProgress($point)
{
	if($point <= 0)
	{
		$progress = '100/100 (100%) ';
	}
	else if($point > 0 and  $point < 1000)
	{
			if($point < 100)
			{
				$percent 	  = ($point/100) * 100;
				$progress 	  = $point.'/100 '.'('.$percent.'%)';
				
			}
			else
			{
				$point_start  = substr($point,0,1);
				$point_multp  = $point_start * 100;
				$val		  = $point  - $point_multp ;// Eg: getting 20 from 120
				$percent 	  = ($val/100) * 100;
				$progress 	  = $val.'/100 '.'('.round($percent,2).'%)';
			}
	}

	else if($point >= 1000 and  $point < 3000)
	{
				
		$val_array  = array(1000,1200,1400,1600,1800,2000,2200,2400,2600,2800,3000);
		for($i=0;$i<11;$i++)
		{
			$k = $i+1;

			if($point >= $val_array[$i] and $point <= $val_array[$k] )
			{
				$minval 	= $val_array[$i];
				$maxval 	= $val_array[$k];
				$resval 	= $point - $minval;
				$percent 	= ($resval/200) * 100;
				$progress 	 = $resval.'/200 '.'('.round($percent,2).'%)';
			}
		}

	}

	else if($point >= 3000 and  $point < 6000)
	{
		$val_array  = array(3000,3300,3600,3900,4200,4500,4800,5100,5400,5700,6000);
		for($i=0;$i<11;$i++)
		{
			$k = $i+1;

			if($point >= $val_array[$i] and $point <= $val_array[$k] )
			{
				$minval 	= $val_array[$i];
				$maxval 	= $val_array[$k];
				$resval 	= $point - $minval;
				$percent 	= ($resval/300) * 100;
				$progress 	 = $resval.'/300 '.'('.round($percent,2).'%)';
				
			}
		}
	}



	else if($point >= 6000 and  $point < 10000)
	{

		$val_array  = array(6000,6400,6800,7200,7600,8000,8400,8800,9200,9600,10000);
		for($i=0;$i<11;$i++)
		{
			$k = $i+1;

			if($point >= $val_array[$i] and $point <= $val_array[$k] )
			{
				$minval 	= $val_array[$i];
				$maxval 	= $val_array[$k];
				$resval 	= $point - $minval;
				$percent 	= ($resval/400) * 100;
				$progress 	 = $resval.'/400 '.'('.round($percent,2).'%)';
				
			}
		}

	}

	else if($point >= 10000 and  $point < 15000)
	{
		$val_array  = array(10000,10500,11000,11500,12000,12500,13000,13500,14000,14500,15000);
		for($i=0;$i<11;$i++)
		{
			$k = $i+1;

			if($point >= $val_array[$i] and $point <= $val_array[$k] )
			{
				$minval 	= $val_array[$i];
				$maxval 	= $val_array[$k];
				$resval 	= $point - $minval;
				$percent 	= ($resval/500) * 100;
				$progress 	 = $resval.'/500 '.'('.round($percent,2).'%)';
				
			}
		}

	}

	else if($point >= 15000 and  $point < 21000)
	{
		$val_array  = array(15000,15600,16200,16800,17400,18000,18600,19200,19800,20400,21000);
		for($i=0;$i<11;$i++)
		{
			$k = $i+1;

			if($point >= $val_array[$i] and $point <= $val_array[$k] )
			{
				$minval 	= $val_array[$i];
				$maxval 	= $val_array[$k];
				$resval 	= $point - $minval;
				$percent 	= ($resval/600) * 100;
				$progress 	 = $resval.'/600 '.'('.round($percent,2).'%)';
				
			}
		}

	}

	else if($point >= 21000 and  $point < 28000)
	{
		$val_array  = array(21000,21700,22400,23100,23800,24500,25200,25900,26600,27300,28000);
		for($i=0;$i<11;$i++)
		{
			$k = $i+1;

			if($point >= $val_array[$i] and $point <= $val_array[$k] )
			{
				$minval 	= $val_array[$i];
				$maxval 	= $val_array[$k];
				$resval 	= $point - $minval;
				$percent 	= ($resval/700) * 100;
				$progress 	 = $resval.'/700 '.'('.round($percent,2).'%)';
				
			}
		}
	}

	else if($point >= 28000 and  $point < 36000)
	{
		$val_array  = array(28000,28800,29600,30400,31200,32000,32800,33600,34400,35200,36000);
		for($i=0;$i<11;$i++)
		{
			$k = $i+1;

			if($point >= $val_array[$i] and $point <= $val_array[$k] )
			{
				$minval 	= $val_array[$i];
				$maxval 	= $val_array[$k];
				$resval 	= $point - $minval;
				$percent 	= ($resval/800) * 100;
				$progress 	 = $resval.'/800 '.'('.round($percent,2).'%)';
				
			}
		}
	}

	else if($point >= 36000 and  $point < 45000)
	{
		$val_array  = array(36000,36900,37800,38700,39600,40500,41400,42300,43200,44100,45000);
		for($i=0;$i<11;$i++)
		{
			$k = $i+1;

			if($point >= $val_array[$i] and $point <= $val_array[$k] )
			{
				$minval 	= $val_array[$i];
				$maxval 	= $val_array[$k];
				$resval 	= $point - $minval;
				$percent 	= ($resval/900) * 100;
				$progress 	 = $resval.'/900 '.'('.round($percent,2).'%)';
				
			}
		}
	}

	else if($point >= 45000 and  $point <= 55000)
	{
		$val_array  = array(45000,46000,47000,48000,49000,50000,51000,52000,53000,54000,55000);
		for($i=0;$i<11;$i++)
		{
			$k = $i+1;

			if($point >= $val_array[$i] and $point <= $val_array[$k] )
			{
				$minval 	= $val_array[$i];
				$maxval 	= $val_array[$k];
				$resval 	= $point - $minval;
				$percent 	= ($resval/1000) * 100;
				$progress 	 = $resval.'/1000 '.'('.round($percent).'%)';
				
			}
		}
	}

	return $progress;

}
#

function numberToWordPosition($number)
{
	if(!is_numeric($number) and !is_array($number))
	return false;
	
	if(is_array($number))
	{
		$result	=	array();
		foreach($number as $no)
		{
			$result[]	=	$this->numberToWordPosition($no);
		}
		return implode(', ',$result);
	}
	
	switch($number)
	{
		case 1:
			return 'first';
		case 2:
			return 'second';
		case 3:
			return 'third';
		case 4:
			return 'fourth';
		case 5:
			return 'fifth';
		default:
			return false;	
	}
}

#Getting current URl, with url_origin and full_url
function url_origin( $s, $use_forwarded_host = false )
{
    $ssl      = ( ! empty( $s['HTTPS'] ) && $s['HTTPS'] == 'on' );
    $sp       = strtolower( $s['SERVER_PROTOCOL'] );
    $protocol = substr( $sp, 0, strpos( $sp, '/' ) ) . ( ( $ssl ) ? 's' : '' );
    $port     = $s['SERVER_PORT'];
    $port     = ( ( ! $ssl && $port=='80' ) || ( $ssl && $port=='443' ) ) ? '' : ':'.$port;
    $host     = ( $use_forwarded_host && isset( $s['HTTP_X_FORWARDED_HOST'] ) ) ? $s['HTTP_X_FORWARDED_HOST'] : ( isset( $s['HTTP_HOST'] ) ? $s['HTTP_HOST'] : null );
    $host     = isset( $host ) ? $host : $s['SERVER_NAME'] . $port;
    return $protocol. '://' . $host;
}

function full_url( $s, $use_forwarded_host = false )
{
  return $this->url_origin( $s, $use_forwarded_host ) . $s['REQUEST_URI'];
	//return $this->url_origin( $s, $use_forwarded_host ) . $s['QUERY_STRING'];
	
}

#  Paging Javascript
	function pagingJS()
	{
    	$_data = <<<JS_DATA
		<script language="javascript" type="text/javascript">
		<!--
		function sespaging()
		{
  			this.totalPages = {$this->page['TOTAL']};
  			this.currentPage = {$this->page['CURRENT']};
  			this.check = function(new_page)
			{
				if(new_page < 1 || new_page > this.totalPages)
				{
	  				alert('Page ['+new_page+'] cannot be found!');
	  				return false;
				}
				if(this.currentPage == new_page)
				{
	  				alert('You are already on this Page!');
	  				return false;
				}
				return true;
  			}	
  			this.goTo = function(choice)
			{
				var obj = document.getElementById('SP_NO');
				var page = parseInt(obj.value);
				if(choice == 2){ // Next Page
				  page++;
				}else if(choice == 0){ // Previous Page
				  page--;
				}
				if(this.check(page)){
				  obj.value = page;
				  return true;
				}
				return false;
  			}
		}
		var sespaging = new sespaging();
		//-->
</script>
JS_DATA;
return $_data;
 }
}?>