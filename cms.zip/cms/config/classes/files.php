<?php
/**************************************************************************
 *  Code @cmsFaiz
 *  Developed by Faiz Kalodi
 *  Purpose: For all operations
 *  (c) All Rights Reserved 
 *  Last Updated on 10 April 2020
 *************************************************************************/
class files extends tableObject{

	function files()
	{
		$this->reset('files', 'id', 'type,title,file,time');
	}
	
	/*function getBanners($type)
	{
		$query  =  "SELECT * FROM `$this->table` WHERE `type` = '{$type}' ORDER by `order` ASC "; 
		$res    =   mysql_query($query) or die(mysql_error());
		return($res);
	}*/
	
	
	
	
#
}
?>