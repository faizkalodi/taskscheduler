<?php
/**************************************************************************
 *  Code @cmsFaiz
 *  Developed by Faiz Kalodi
 *  Purpose: For all operations
 *  (c) All Rights Reserved 
 *  Last Updated on 2017 June 1
 *************************************************************************/
class page extends tableObject{

	function page()
	{
		$this->reset('page', 'id', 'id,banner,icon,page_name,page_desc,page_desc2,meta_title,meta_desc,meta_keywords,order,time');
	}
	
	function getAll()
	{
		$query  =  "SELECT * FROM `$this->table` "; 
		$res    =   mysql_query($query) or die(mysql_error());
		return $res ;
	}
	
#
}
?>