<?php
/*
*/
class paging{
  var $sql = false,
	  $size = false,
	  $order = false,
	  $no = 1,
	  $total = 0;
  function paging($sql, $size = 12){
	$this->sql = $sql;
	$this->size = $size;
	$this->order = 'id';
  }
  
  function getPage($no, $condn = 1){
	if($no == $this->no){
	  return false;
	}
	//-
	$html = "";
	$db = mysql_query("{$this->sql} WHERE({$condn}) ORDER BY {$this->order} LIMIT 0, {$this->size};") or die(mysql_error());
	$num_fields = mysql_num_fields($db);
	while($row = mysql_fetch_array($db, MYSQL_NUM)){
	  $html .= "<tr>";
	  for($i = 0; $i < $num_fields; $i++){
		$html .= "<td>{$row[$i]}</td>";
	  }
	  $html .= "</tr>";
	}
	return $html;
  }

  function firstPage(){
	return $this->getPage(1);
  }
  function lastPage(){
	return $this->getPage($this->total);
  }
  function prevPage(){
	return $this->getPage($this->no - 1);
  }
  function nextPage(){
	return $this->getPage($this->no + 1);
  }
	
  function pagingControls(){

  }
}
/**/
$conn = mysql_connect('localhost', 'user', '');
mysql_select_db("ses_cms2");
$obj = new paging("SELECT * FROM `xx_category`");
?>
<table width="96%" border="0">
  <thead>
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
  </thead>
  <tbody>
    <?php echo $obj->getPage(1);?>
  </tbody>
  <tfoot>
    <tr>
      <td colspan="4"><form name="form1" method="post" action="">
        <input name="condn" type="hidden" id="condn" value="1">
        <input name="imgFirst" type="image" id="imgFirst" src="../images/pfirst.png" alt="First">
        <input name="imgPrevious" type="image" id="imgPrevious" src="../images/pprevious.png" alt="Previous">
        <input name="imgNext" type="image" id="imgNext" src="../images/pnext.png" alt="Next">
        <input name="imgLast" type="image" id="imgLast" src="../images/plast.png" alt="Last">
      &nbsp;&nbsp;
      <input name="textfield" type="text" size="5">
        <input name="imgGo" type="image" id="imgGo" src="../images/yes.png" alt="Go">
        <input name="of" type="hidden" id="of">
        <input name="od" type="hidden" id="od">
      </form>
      </td>
    </tr>
  </tfoot>
</table>