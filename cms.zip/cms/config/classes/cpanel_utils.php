<?php 
/**
 * Definition for the cpanel_utils class
 * @methode Definition constructor cpanel_utils() for database activity 
 */
class cpanel_utils{
  var 	$files 		= 	array();
  var	$deleteMessage, $viewLink, $editLink, $deleteLink;
  var 	$module		=	false;
#---
	function cpanel_utils()
	{
  		$this->deleteMessage	=	'Is it really okay to remove this record?';
		$this->viewLink			=	'view.php';
		$this->editLink			= 	'edit.php';
		$this->deleteLink		=	'do.php';		
  	}
#---

/**
 * @methode Definition  Operations()
 * @global object of class application
 */
function Operations($key, $singleID = true, $controls = 'V/E/D', $module = false)
{
	global $App;
	if($singleID){ 
	  $key = "id={$key}&";
	}
	$img = $App->dir("/lenapc/images", false);
	$_code = "";
	
	$controls	=	explode("/",$controls);
	$controls	=	array_unique($controls);
	$ctrls		=	array();
	foreach($controls as $ctrl)
	$ctrls[$ctrl]	=	$ctrl;
	$controls		=	$ctrls;
	
	
	
	if($module)
	{
		$user	=	new user(true);
		$rights	=	$user->getRights($module);
		
		if(!$rights['view'] and in_array('V',$controls))
		{
			unset($controls['V']);
		}	
		if(!$rights['edit'] and in_array('E',$controls))
		{
			unset($controls['E']);
		}	
		if(!$rights['delete'] and in_array('D',$controls))
		{
			unset($controls['D']);
		}
	}
	
	foreach($controls as $control)
	{	
		switch($control)
		{
			case 'B'://Back
				$_code .=     "<a href='javascript:void(0);' onclick='window.history.go(-1)'; title=\"Back\"><img src=\"{$img}/back.png\" alt=\"Back\" border=0/>";
				if(sizeof($controls) == 1)
					$_code	.=	"&nbsp;Back";
				$_code .=     "</a>&nbsp;";
			break;
			case 'V'://View
				$_code .=     "<a href='{$this->viewLink}?{$key}' title=\"View\"><img src=\"{$img}/view.png\" alt=\"View\" border=0/></a>&nbsp;";
			break;
			case 'E'://Edit
    			$_code .=     "<a href='{$this->editLink}?{$key}' title=\"Edit\"><img src=\"{$img}/edit.png\" alt=\"Edit\"/></a>&nbsp;";
			break;
			case 'D'://Delete
    			$_code .=     "<a href='{$this->deleteLink}?op=remove&{$key}' onclick=\"return confirm('{$this->deleteMessage}');\" title=\"Delete\"><img src=\"{$img}/trash.png\" alt=\"Delete\"/></a>";
			break;
		}
	}	
	return $_code;	
}
  
 /**
  * @methode Definition fileSelector(),selects the file
  * @global object of class application
  */
  function fileSelector($dom_id, $dir = "images", $value = false){
	global $App;
	$this->dirTree($App->data($dir));
	$dir = $App->data($dir, false);
	$_code =  "<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\">";
	$_code .= "  <tr>";
	$_code .= "    <td>";
	$_code .= "		  <select name=\"{$dom_id}\" id=\"{$dom_id}\">";
	foreach($this->files as $k => $v){
	  $_code .= ($value == $k) ? "<option value=\"{$k}\" selected=\"selected\">{$v}</option>" : "<option value=\"{$k}\">{$v}</option>";
	}
	$_code .= "		  </select>";
	$_code .= "    </td>";
	$_code .= "    <td>";
	$_code .= "		  <input name=\"btn{$dom_id}\" type=\"button\" class=\"btn_txtbox\" id=\"btn{$dom_id}\" value=\"Preview\" onclick=\"return cmscputils.openImage('{$dom_id}', '{$dir}/');\" />";
	$_code .= "    </td>";
	$_code .= "  </tr>";
	$_code .= "</table>";
	unset($this->files);
	$this->files = array();
	return $_code;
  }
 /**
  * @methode Definition dirTree()
  * Getting  file path
  */
  function dirTree($_dir, $_path = false){
	$dir = opendir($_dir);
	while(false !== ($fname = readdir($dir))){
	  if($fname == '.' || $fname == '..'){
		continue;
	  }elseif(is_dir($_dir.'/'.$fname)){
		$this->dirTree($_dir.'/'.$fname, $_path.$fname.'/');
	  }else{
		$this->files[$_path.$fname] = str_replace('/', ' > ', $_path.$fname);
	  }
	}
	closedir($dir);
	return true;
  }

 /**
  * @methode Definition genList()
  * @global object of class application
  */
  function genList($table, $value, $key = false, $cn = 1, $selected = false){
	global $App;
	$result = "";
	$key = $key ? "`{$key}` AS `key`" : "`{$value}` AS `key`";
	$db[0] = "SELECT {$key}, `{$value}` AS `value` FROM `#{$table}`";
	$db[1] = "WHERE({$cn}) ORDER BY `{$value}` ASC";
	$tp = $App->sql($db[0], $db[1], false);
	if(is_array($selected)){
	  while($r = mysql_fetch_assoc($tp)){
		if(isset($selected[$r['key']])){
		  $result .= "<option value=\"{$r['key']}\" selected=\"selected\">{$r['value']}</option>";
		}else{
		  $result .= "<option value=\"{$r['key']}\">{$r['value']}</option>";
		}
	  }
	}else{
	  while($r = mysql_fetch_assoc($tp)){
		if($r['key'] === $selected){
		  $result .= "<option value=\"{$r['key']}\" selected=\"selected\">{$r['value']}</option>";
		}else{
		  $result .= "<option value=\"{$r['key']}\">{$r['value']}</option>";
		}
	  }
	}
	return $result;
  }
#---
}?>