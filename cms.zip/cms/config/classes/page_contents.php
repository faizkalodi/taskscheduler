<?php
/**************************************************************************
 *  Code @cmsFaiz
 *  Developed by Faiz Kalodi
 *  Purpose: For all operations
 *  (c) All Rights Reserved 
 *  Last Updated on 2017 June 1
 *************************************************************************/
class page_contents extends tableObject{
	
	
	function page_contents()
	{
		$this->reset('page_contents', 'id', 'page_id,title,details,order,time');
	}
	
	function deleteItems($pid)
	{
		$query = "DELETE FROM `$this->table` WHERE `page_id` = '{$pid}' ";
		$res   = mysql_query($query)or die(mysql_error());
		return true;
	}
		
	function getContentCount($id)
	{
		$query = "SELECT * FROM `$this->table` WHERE `page_id` = '{$id}' ";
		$res   = mysql_query($query)or die(mysql_error());
		return($res);
	}
	
	function getContents($id)
	{
		$query = "SELECT * FROM `$this->table` WHERE `page_id` = '{$id}' ORDER BY `order` DESC ";
		$res   = mysql_query($query)or die(mysql_error());
		return($res);
	}
	
}
?>