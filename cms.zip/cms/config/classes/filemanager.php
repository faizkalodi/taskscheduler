<?php
/*
 * Definition for the class `filemanager`
 * @methode Definition constructor filemanager()
 */
class filemanager extends tableObject
{
	var $fileid;
	function filemanager()
	{
		$this->reset('filemanager', 'id','user_id,filename,stored_file_name,file_type,file_category,folder_id,server_id,filesize,ctime,time,upto,last_access,downloads,status,privacy,protected,password,parent,description');
		$this->fileid = false;
  	}
	
	/*
	// To get count of files in a folder
	*/
	function getFilesCount($folderId = 0, $userId, $all = false)
	{
		if($all)
		$db 	= 	"SELECT COUNT(*) FROM `{$this->table}` WHERE(`user_id` = '{$userId}');";
		else
		$db 	= 	"SELECT COUNT(*) FROM `{$this->table}` WHERE(`folder_id` = '{$folderId}' AND `user_id` = '{$userId}');";
		//die($db);
		if($db	=	mysql_query($db))
		$row	=	mysql_fetch_array($db);
		return (int)$row[0];
	}
		
	/*
	// To get count of files of a user
	*/
	function getTotalFiles($userId)
	{
		$db 	= 	"SELECT COUNT(*) FROM `{$this->table}` WHERE (`user_id` = '{$userId}');";
		if($db	=	mysql_query($db))
		$row	=	mysql_fetch_array($db);
		return (int)$row[0];	
	}
	
	/*
	// To get space usage of a user
	*/
	function getTotalSpaceUsed($userId)
	{
		$db 	= 	"SELECT SUM(`filesize`) FROM `{$this->table}` WHERE (`user_id` = '{$userId}');";
		//die($db);
		if($db	=	mysql_query($db))
		$row	=	mysql_fetch_array($db);
		return $this->displayFileSize($row[0],true);	
	}
	
	function displayFileSize($filesizeinbytes = 0, $filesizegiven = false)
	{
		$fileSize	=	($filesizegiven)?$filesizeinbytes:$this->value['filesize'];
		$sizeUnits	=	array('Bytes','KB','MB','GB','TB');
		$i			=	0;
		$Unit		=	$sizeUnits[0];		
		
		for($i = 0; $fileSize > 1024 && $i < sizeof($sizeUnits); $i++)
		{
			$fileSize	= 	$fileSize / 1024;
			$Unit		=	$sizeUnits[$i+1];	
		}
		
		$fileSize	=	number_format($fileSize,2,'.','');
		return $fileSize.' '.$Unit;
	}
	
	function encodeDownloadLink($fileId)
	{
		$fileId		=	(int)$fileId;
		return ($fileId)?$this->idEncode($fileId.'_'.time()):false;
	}
	
	function validateDownload($id)
	{
		$value		=	$this->idDecode($id);
		$value		=	explode('_',$value);
		$id			=	false;
		if(is_array($value) and sizeof($value) == 2)
		{
			$timeVar			=	$value[1];
			$fileId				=	$value[0];
			$timeDifference		=	time() - $timeVar;
			$timeDifference		=	$timeDifference / (60 * 60); 	// in hours
			
			if($timeDifference < 24)
			{
				$id		=	$fileId;	//	download link is valid for 24 Hrs only
			}
			else
			{
				$this->fileid	=	$fileId;
			}				
		}
		return $id;
	}
	
	function getFiles($folderId = 0, $userId, $shared = false)
	{
		if($shared)
		$db 	= 	"SELECT `filename`,`id`,`stored_file_name`,`server_id` FROM `{$this->table}` WHERE (`folder_id` = '{$folderId}' AND `user_id` = '{$userId}' AND `privacy` = 0 AND `protected` = 0);";
		else
		$db 	= 	"SELECT `filename`,`id`,`stored_file_name`,`server_id` FROM `{$this->table}` WHERE (`folder_id` = '{$folderId}' AND `user_id` = '{$userId}');";
		
		$result	=	array();
		if($db	=	mysql_query($db))
		{
			while($row	=	mysql_fetch_array($db))
			$result[$row['id']]	=	$row;
		}
		return $result;
	}
	
	function checkCopy()
	{
		$db		=	"SELECT COUNT(*) FROM `{$this->table}` WHERE (`parent` = '{$this->value[id]}')";
		if($db	=	mysql_query($db))
		$row	=	mysql_fetch_array($db);
		return (int)$row[0];
	}
	
	function checkId($id)
	{
		$db		=	"SELECT `id` FROM `{$this->table}` WHERE (`id` = '{$id}')";
		$db		=	mysql_query($db);
		return mysql_num_rows($db)?true:false;
	}
	
	function deleteFile()
	{
		if($this->checkCopy() > 0) 					// Copy exists, delete db row only
		{
			$this->delete();
		}
		else
		if($this->value['parent'] == 0) 			//	No Copy exists for the file, and the file is not copied from any where, delete both the db row and physical file
		{
			$this->deletePhysicalFile();
			$this->delete();
		}	
		else
		if($this->checkId($this->value['parent']))	// The file has been originated from its parent, which is exists. Delete the child file db row only
		{			
			$this->delete();
		}
		else										// The file had a parent, which is already deleted. Delete both the db row and physical file 				
		{			
			$this->deletePhysicalFile();
			$this->delete();
		}
		return true;
	}
	
	function deletePhysicalFile()
	{
		$server				=	new servers;
		$server->key['id']	=	$this->value['server_id'];
		$server->select();
		
		$conn_id 	= 	ftp_connect($server->value['serverip'],$server->value['port']) or die ("Cannot connect to host");
	 
		// send access parameters
		ftp_login($conn_id, $server->value['username'], $server->value['password']) or die("Cannot login");
		//return (ftp_delete($conn_id, $this->value['stored_file_name']))?true:false;
		@ftp_delete($conn_id, $this->value['stored_file_name']);
		return true;
	}
	
	function addToZip($folderId, $userId, $tempfolderNm, $zipFolderName, $shared = false)
	{
		global $App;
		global $zip;
		global $server;
		
		$zipFolderName	=	empty($zipFolderName)?'':$zipFolderName.'/';
		
		$fileList	=	$this->getFiles($folderId,$userId,$shared);
		if(is_array($fileList) and sizeof($fileList))
		{
			foreach($fileList as $fileInfo)
			{				
				$local_file 		= 	$fileInfo['filename'];
				$server_file 		= 	$fileInfo['stored_file_name'];
				
				$server->key['id']	=	$fileInfo['server_id'];
				$server->select();
				
				// set up ftp connection
				$conn_id 			= 	ftp_connect($server->value['serverip']);
				
				if(!$login_result 		= 	@ftp_login($conn_id, $server->value['username'], $server->value['password']))
				$App->message("Could not connect to the Storage server.<br/>","Connection error.",false,false,'back');
				
				$serverDir	=	explode("/",$server_file);
				$dirDepth	=	sizeof($serverDir);
				if($dirDepth > 1)
				{
					for($i = ($dirDepth - 2); $i >=0; $i--)
					{
						ftp_chdir($conn_id, '/'.$serverDir[$i]);
					}	
				}
				$server_file	=	end($serverDir);
			
				$contents_on_server = ftp_nlist($conn_id, '');
				if (in_array($server_file, $contents_on_server)) 
				{
					if(ftp_get($conn_id, $tempfolderNm.'/'.$local_file, $server_file, FTP_BINARY))
					$zip->addFile($tempfolderNm.'/'.$local_file, $zipFolderName.$local_file);	
					$itemCount++;  	
					// $zip->addEmptyDir('hello');
				}	
			}
		}		
	}
	
	function ftype($f) 
	{
         curl_setopt_array(($c = @curl_init((!preg_match("/[a-z]+:\/{2}(?:www\.)?/i",$f) ? sprintf("%s://%s/%s", "http" , $_SERVER['HTTP_HOST'],$f) :  $f))), array(CURLOPT_RETURNTRANSFER => 1, CURLOPT_HEADER => 1));
         return(preg_match("/Type:\s*(?<mime_type>[^\n]+)/i", @curl_exec($c), $m) && curl_getinfo($c, CURLINFO_HTTP_CODE) != 404)  ? ($m["mime_type"]) : '';
     }


	 function extensionToType($ext)
	 {
	 	$ext	=	str_replace('.','',$ext);
		
	 	$image	=	array('bmp','gif','jpg','png','psd','pspimage','thm','tif','yuv');
		if(in_array($ext,$image))
		return 1;
		
		$video	=	array('3g2','3gp','asf','asx','avi','flv','mov','mp4','mpg','rm','swf','vob','wmv');
		if(in_array($ext,$video))
		return 2;
		
		$audio	=	array('aif','iff','m3u','m4a','mid','mp3','mpa','ra','wav','wma');
		if(in_array($ext,$audio))
		return 3;
		
	 	$doc	=	array('doc','docx','log','msg','pages','rtf','txt','wpd','wps');
		if(in_array($ext,$doc))
		return 4;
		
		$spreadsheet	=	array('xlr','xls','xlsx');
		if(in_array($ext,$spreadsheet))
		return 5;
		
		$presentation	=	array('pps','ppt','pptx');
		if(in_array($ext,$presentation))
		return 6;
		
		return false;
	 }


}
?>