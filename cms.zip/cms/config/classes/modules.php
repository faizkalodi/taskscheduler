<?php
/**************************************************************************
 *  Code @cmsFaiz
 *  Developed by Faiz Kalodi
 *  Purpose: For all operations
 *  (c) All Rights Reserved 
 *  Last Updated on 2017 June 1
 *************************************************************************/
class modules extends tableObject{
	
	
	function modules()
	{
		$this->reset('modules', 'id', 'module_title,module_table,time');
	}
	
	function getAll()
	{
		$query = "SELECT * FROM `$this->table` ORDER BY `module_title` ASC ";
		$res   = mysql_query($query)or die(mysql_error());
		return($res);
	}
	
}
?>