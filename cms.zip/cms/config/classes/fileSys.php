<?php
/**
  * @Definition for `fileSys` class
  * @Description: Creates a file system around the specified subdirectory under the '$App->data()' directory
  */
class fileSys{
  var $error,
	  $message,
	  $rootDir,
	  $maxSpace = 0,
	  $enabled = array(
		'txt' => 'Text Document',
	  	'doc' => 'Microsoft Word Document',
	  	'pdf' => 'PDF Files'
		);
/*
 * @Definition: Constructor
 * @Description: Sets the Root directory of the File System to be created,
 *	and optionally the maximum size of files uploadable to the same.
 */
  function fileSys($dir, $maxSpace = 0){
	$this->rootDir = $dir;
	$this->setMaxSpace($maxSpace);
  }
 /**
  * @methode Definition setMaxSpace(), setting the maximum uploadable space directly or from a setting(file)
  */
  function setMaxSpace($sizeInMB){
	global $App;
	if(is_string($sizeInMB)){
	  $sizeInMB = file($App->data($sizeInMB));
	  $sizeInMB = $sizeInMB[0];
	}
	$this->maxSpace = $this->mb2b($sizeInMB);
	return $this->maxSpace;
  }
 /**
  * @methode Definition getDir(),getting the directory path  
  * @global object of class application
  */
  function getDir($dir, $subdir = true){
	global $App;
	$dir = $dir."/";
	$result = array();
  	$dh = opendir($App->data($dir));
	while(false !== ($fname = readdir($dh))){
	  if($fname == '.' || $fname == '..'){
		continue;
	  }elseif(is_file($App->data($dir.$fname))){
		$result[$fname] = $dir.$fname;
	  }elseif($subdir){
		$result[$fname] = $this->getDir($dir.$fname);
	  }
	}
	closedir($dh);
	ksort($result);
	return $result;
  }
 /**
  * @methode Definition doUpload(), for upload  file
  * @global object of class application
  */
  function doUpload($fKey, $dir, $maxFileSizeInMB = false){
	global $App, $_FILES;
	$name = strtolower($_FILES[$fKey]['name']);
	if(file_exists($dir.$name)){
	  $this->message = "A file in this name already exists in the specified location!";
	  return false;
	}
	if(!$this->isAllowed($name)){
	  $this->message = "Sorry, This kind of files are not accepted!";
	  return false;
	}
	if($maxFileSizeInMB && $_FILES[$fKey]['size'] > $this->mb2b($maxFileSizeInMB)){
	  $this->message = "Your file is too large max size, allowed is {$maxFileSizeInMB}MB!";
	  return false;
	}
	if($_FILES[$fKey]['size'] > $this->freeSpace()){
	  $this->message = "Sorry, There is not enough free space to upload this file!";
	  return false;
	}
	return move_uploaded_file($_FILES[$fKey]['tmp_name'], $dir.$name);
  }
/**
  * @methode Definition isAllowed(),checks the file is alllowed or not
  * @param string  file name
  */
  function isAllowed($name){
	$name = array_pop(explode('.', $name));
	if(isset($this->enabled[$name])){ return true;}
	return false;
  }

  function freeSpace(){
    return ($this->maxSpace - $this->dir_size($this->rootDir));
  }
  
/**
  * @Definition for `mb2b` method
  * @Description: Convert MB to Bytes
  */
  function mb2b($_mb){
    $_mb *= (1024 * 1024); 
	return round($_mb, 2);
  }

/**
  * @Definition for `b2mb` method
  * @Description: Convert Bytes to MB
  */
  function b2mb($_b){
    $_b /= (1024 * 1024);
	return round($_b, 2);
  }
  
/**
  * @Definition for `size` method
  * @Description: Returns the size of a subdirectory of in Bytes
  */
  function size($subdir = false, $fullPath = false){
	if($fullPath){
	  $_dir = $subdir;
	}else{
	  global $App;
	  $_dir = $subdir
				? $App->data("{$this->rootDir}/{$subdir}")
				: $App->data($this->rootDir);
	}
	$_dir = rtrim($_dir, '/');
	$_size = 0;
	$dh = @opendir($_dir);
	while (false !== ($_f = @readdir($dh))){
	  $fh = "{$_dir}/{$_f}";
	  if($_f == '.' || $_f == '..'){
		continue;
	  }elseif(is_dir($fh)){
		$_size += $this->size($fh, true);
	  }elseif(is_file($fh)){
		$_size += filesize($fh);
	  }
	}
	@closedir($dh);
	return $_size;
  }

/**
  * @Definition for `count` method
  * @Description: Returns the count of files, directories in a sub directory
  */
  function count($subdir = false, $fullPath = false){
	if($fullPath){
	  $_dir = $subdir;
	}else{
	  global $App;
	  $_dir = $subdir
				? $App->data("{$this->rootDir}/{$subdir}")
				: $App->data($this->rootDir);
	}
	$_dir = rtrim($_dir, '/');
	$_count = array('file' => 0,
					'dir' => 0);
	//-
	$dh = @opendir($_dir);
	while (false !== ($_f = @readdir($dh))){
	  $fh = "{$_dir}/{$_f}";
	  if($_f == '.' || $_f == '..'){
		continue;
	  }elseif(is_dir($fh)){
		$_count['dir']++;
	    $tp = $this->count($fh, true);
		$_count['dir'] += $tp['dir'];
		$_count['file'] += $tp['file'];
	  }elseif(is_file($fh)){
		$_count['file']++;
	  }
	}
	@closedir($dh);
	return $_count;
  }
/*
 * Mehodname: readFS
 * Description: Reads the specified directory contents to Array
 * Arguements:
 * Returns: The File / dir list @Array
 */
  function readFS($dir){
	global $App;
	$res = array();
	$dh = opendir($App->data($dir, true));
	while(false !== ($fn = readdir($dh))){
	  if($fn == '.' || $fn == '..'){
		continue;
	  }else{
		$res[$fn] = is_dir($App->data("{$dir}/{$fn}", true)) 
					  ? $this->readFS("{$dir}/{$fn}")
					  : "{$dir}/{$fn}";
	  }
	}
	closedir($dh);
	ksort($res);
	return $res;
  }

/*
 * Mehodname: readDir
 * Description: Reads (Only) Current directory contents to Array
 * Arguements: Nil
 * Returns: The File / dir list @Array
 */
  function readDir(){
	global $App;
	$res = array();
	$dir = trim($this->rootDir, " /");
	$dh = opendir($App->data($dir, true));
	while(false !== ($fn = readdir($dh))){
	  if($fn == '.' || $fn == '..'){
		continue;
	  }elseif(is_dir($App->data("{$dir}/{$fn}", true))){
		$res[$fn] = true;
	  }else{
		$res[$fn] = "{$dir}/{$fn}";
	  }
	}
	closedir($dh);
	ksort($res);
	return $res;
  }

/*
 * Mehodname: htmlMenuOptions()
 * Conveert Array to select tag
 */
  function htmlMenuOptions($dir = '', $selected = false){
	global $App;
	$html = "";
  	$dh = opendir($App->data($this->rootDir.$dir, true));
	while(false !== ($fname = readdir($dh))){
	  if($fname == '.' || $fname == '..'){
		continue;
	  }elseif(is_file($App->data("{$this->rootDir}{$dir}/{$fname}", true))){
		$value = "/{$this->rootDir}{$dir}/{$fname}";
		if($selected == $value){
			$html .= "<option value=\"{$value}\" selected=\"selected\">{$value}</option>";
		}else{
			$html .= "<option value=\"{$value}\">{$value}</option>";
		}
	  }else{
		$html .= $this->htmlMenuOptions("{$dir}/{$fname}");
	  }
	}
	closedir($dh);
	return $html;
  }
/*
 * Mehodname: htmlMenu()
 * Menu options
 */
  function htmlMenu($domId, $title = false, $selected = false){
	global $App;
	$title = " title=\"" . ($title ? $title : $domId). "\"";
	$html = "<select id=\"{$domId}\" name=\"{$domId}\"{$title}>";
	$html .= "<option value=\"\">[ Select ]</option>";
	$html .= $this->htmlMenuOptions('', $selected);
	$html .= "</select>";
	$html .= "<a href=\"#\" onclick=\"if($('#{$domId}').val().length > 1){ this.href = '".($App->data("", false))."' + $('#{$domId}').val(); return true;}return false;\" target=\"_blank\"><img src=\"".$App->dir("config/images/viw.gif", false)."\" alt=\"Preview\" width=\"16\" height=\"16\" /></a>";
	echo $html;
	return true;
  }
}?>