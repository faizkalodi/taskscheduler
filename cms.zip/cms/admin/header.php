<?php
if(empty($_SESSION['UID']))
{
	header("location:../admin/index.php?error_msg=invalid");
}
?>
  <header class="main-header">
        <!-- Logo -->
        <a href="../../index.php" class="logo">
          <!-- mini logo for sidebar mini 50x50 pixels -->
          <span class="logo-mini"><b>Admin</b>Panel</span>
          <!-- logo for regular state and mobile devices -->
          <span class="logo-lg"><b>Admin</b>Panel</span>        </a>
        <!-- Header Navbar: style can be found in header.less -->
        <nav class="navbar navbar-static-top" role="navigation">
          <!-- Sidebar toggle button-->
          <a href="#" class="sidebar-toggle hidden" data-toggle="offcanvas" role="button">
            <span class="sr-only">Toggle navigation</span>          </a>
          <div class="navbar-custom-menu">
            <ul class="nav navbar-nav">
              <!-- Messages: style can be found in dropdown.less--><!-- User Account: style can be found in dropdown.less -->
              <li class="dropdown user user-menu">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                 
                 <?php 
				 if(empty($user->value['image']))
				 {
				 ?>
                  <img src="../../dist/img/user2-160x160.jpg" class="user-image" alt="User Image">
                 <?php }else{ ?>
                  
                  <?php if (file_exists($App->data("users/{$user->value['image']}", true))){ ?>
					<img src=" <?php  echo $App->data("users/{$user->value['image']}", false); ?>" alt="<?php echo $user->value['image'];?>" class="user-image"  >
				  <?php 
					    }
				    }
				  ?>
                    
                  <span class="hidden-xs">Welcome <?php echo ucfirst($user->value['name']); ?></span> </a>
                  
                  	
                  
                  
                <ul class="dropdown-menu">
                  <!-- User image -->
                  <li class="user-header">
                  <br />

                    <?php 
				 	if(empty($user->value['image']))
					 {
					 ?>
                 		 <img src="../../dist/img/user2-160x160.jpg" class="user-image" alt="User Image"> 
					 <?php }else{ ?>
                  
					  <?php 
					  if (file_exists($App->data("users/{$user->value['image']}", true))){ ?>
                        <img src=" <?php  echo $App->data("users/{$user->value['image']}", false); ?>" alt="<?php echo $user->value['image'];?>"  style="max-width:300px;border:none; margin: 0 auto;"  >
                      <?php 
                            }
                        }
                      ?>
                  
                    
                     
                    
                    
                    <p>
                      <?php echo ucfirst($user->value['name']); ?> 
                        <small> Welcome <?php echo $user->value['uname']; ?></small> </p><br />

                  </li>
                  
                   <!-- Menu Body -->
                  <li class="user-body">
                                       
                    
                        
                     	<div  align="center">
                          <a href="../user/changepass.php?op=edit&id=<?php echo $user->value['id']; ?>">Change Password</a>
                        </div>
                  </li>
                  
                  
                  <!-- Menu Footer-->
                   <li class="user-footer">
                        
                        <div class="pull-left">
                          <a href="../user/myprofile.php?op=edit&id=<?php echo $user->value['id']; ?>" class="btn btn-default btn-flat">Profile</a>
                        </div>
                        
                       
                        
                        <div class="pull-right">
                          <a href="../user/do.php?op=signout" class="btn btn-default btn-flat">Sign out</a>
                        </div>
                   </li>
                                    
                                    
                                    
                </ul>
              </li>
              <!-- Control Sidebar Toggle Button -->
            </ul>
          </div>
        </nav>
      </header>