<?php
require_once('../../../config/application.php');

switch(strtolower((empty($_GET['op']) ? empty($_POST['op']) ? false : trim($_POST['op']) : trim($_GET['op'])))){
 
 	
	case 'new':
	/**
 	 * Add new 
 	 */
	
	$App->setup(true, 'user,task', true, 'task:new');
	$user 						= 	new user();
	$obj 						= 	new task;
	#
	$obj->value['id']				=	$obj->nextID();
	$obj->value['title'] 			= 	$_POST['title'];
	$obj->value['details'] 			= 	$_POST['details'];
	$obj->value['estimated_time'] 	= 	$_POST['estimated_time'];
	$obj->value['priority'] 		= 	$_POST['priority'];
	$obj->value['alloted_to'] 		= 	$_POST['employee'];
	$obj->value['alloted_date'] 	= 	$_POST['alloted_date'];
	$obj->value['alloted_by'] 		= 	$_POST['alloted_by'];
	$obj->value['status'] 			= 	$_POST['status'];
	#

	if(empty($_SESSION['UID']))
	{
		header("location:../../index.php?error_msg=auth");
	}
	else
	{
				
		if(empty($_POST['title']) or empty($_POST['details']) or empty($_POST['estimated_time']) or empty($_POST['priority']) )
		{
			header("location:task.php?op=new&&error_msg=empty");
		}
			
		else
		{
			#insert data
			if($obj->insert())
			{
				header("location:task.php?op=add");
			}
			else
			{
				header("location:.task.php?op=new&&error_msg=failed");
			}
		
		}
		
	}	
	
  	break;
	
	
	
	case 'edit':
	$App->setup(true, 'user,task', true, 'task:task');
	$user 						= 	new user();
	$obj 						= 	new task;
	#
	$id  						= 	$_POST['id'];
	
	
	if(empty($_SESSION['UID']))
	{
		header("location:../../index.php?error_msg=auth");
	}
	else
	{
		if(empty($_POST['title']) or empty($_POST['details']) or empty($_POST['estimated_time']) or empty($_POST['priority']) )
		{
			header("location:task.php?op=edit&id=$id&edit_error_msg=empty");
		}
		else
		{
			
			#update data
			$obj->key['id'] = $_POST['id'];
			if($obj->select())
			{					
				$obj->value['title'] 			= 	$_POST['title'];
				$obj->value['details'] 			= 	$_POST['details'];
				$obj->value['estimated_time'] 	= 	$_POST['estimated_time'];
				$obj->value['priority'] 		= 	$_POST['priority'];
				$obj->value['alloted_to'] 		= 	$_POST['employee'];
				$obj->value['alloted_date'] 	= 	$_POST['alloted_date'];
				$obj->value['alloted_by'] 		= 	$_POST['alloted_by'];
				$obj->value['status'] 			= 	$_POST['status'];
			}
			
			if($obj->update())
			{
				header("location:task.php?op=update");
			}
			else
			{
				header("location:task.php?op=edit&&id=$id&edit_error_msg=failed");
			}
			
		}
		
	}	
	
  	break;
	
	
	case 'delete':
	/**
 	 * Edit 
 	 */
	$App->setup(true, 'user,task', true, 'task:new');
	$user 						= 	new user();
	$obj 						= 	new task;
	#
	if(empty($_SESSION['UID']))
	{
		header("location:../../index.php?error_msg=auth");
	}
	
	else
	{
		#remove image
		
		$obj->key['id'] 				=  $_GET['id'];
		$obj->select();
		$obj->delete();
		header("location:task.php?op=delete");
	}
  	break;
	
# 
}
exit;
?>
