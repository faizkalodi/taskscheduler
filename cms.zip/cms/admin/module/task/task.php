<?php
/**************************************************************************
 *  Code @cmsFaiz
 *  Developed by Faiz Kalodi
 *  Purpose: For all operations
 *  (c) All Rights Reserved 
 *  Last Updated on 10 April 2020
 *************************************************************************/
require_once('../../../config/application.php');
$App->setup(true,'user,task',true,'task:new');
$user 				= 	new user(true);
$obj  				= 	new task;
#
if(empty($_SESSION['UID']))
{
	header("location:../../index.php?error_msg=auth");
}

$msg_op = "";
if($_GET['op'] == 'add')
{
	$msg_op = "New record has been added successfully!";
}

if($_GET['op'] == 'update')
{
	$msg_op = "Specified record has been updated successfully!";
}

if($_GET['op'] == 'delete')
{
	$msg_op = "Specified record has been removed successfully!";
}

if($_GET['op'] == 'delete_about')
{
	$msg_op = "Sorry, this section cannot be deleted!";
}

if($_GET['op'] == 'default_article')
{
	$msg_op = "The record has been changed to default!";
}

#
?>
<!DOCTYPE html>
<html>
  <?php include("../../head.php"); ?>
  <body class="skin-blue sidebar-mini">
    <div class="wrapper">
     <?php include("../../header.php"); ?>
    <?php include("../../sidebar.php");?>
      

      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>Tasks</h1>
          <ol class="breadcrumb">
            <li><a href="../dashboard/dashboard.php"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="task.php">Task</a></li>
          </ol>
        </section>


  			
               
        <!-- Main content -->
        <section class="content">
          <div class="row">
          
         <?php if($_GET['op'] == 'new'){ ?>
          <div class="col-xs-6"  style="margin-left:25%">
              
              <div class="box box-info">
                <div class="box-header with-border">
                  <h3 class="box-title">Add New task</h3>
                </div><!-- /.box-header -->
                    <?php
                    #error display section
					$msg_success ="";
					$msg = "";
					if(!empty($_GET['error_msg']))
					{
					
						if($_GET['error_msg'] == 'empty')
						{
							$msg = "Please enter all required fields!";
						}
						
						if($_GET['error_msg'] == 'failed')
						{
							$msg = "Failed to add!";
						}
						
						if($_GET['error_msg'] == 'success')
						{
							$msg_success = "Added successfully!";
						}
					?>
					
                    <?php if(!empty($msg)){ ?><br><div align="center" style="color:#FF0000"><?php print $msg; ?></div><br><?php } ?>
                    <?php if(!empty($msg_success)){ ?><br><div align="center" style="color:#006633"><?php print $msg_success; ?></div><br><?php } ?>

                   <?php 
				   } 
				   ?>


              
                
                <!-- form start -->
                <form class="form-horizontal" action="do.php" method="post" enctype="multipart/form-data">
                
                 
                  <div class="box-body">
                    
                   
                    <div class="form-group">
                      <label for="inputEmail3" class="col-sm-3 control-label"> Task Title*</label>
                      <div class="col-sm-7">
                       <input type="hidden" name="op" id="op" value="new">
					   <input type="text" name="title" id="title" class="form-control" required>                       
                      </div>
                    </div>
                    
                                 
                     <div class="form-group">
                      <label for="inputEmail3" class="col-sm-3 control-label"> Description *</label>
                      <div class="col-sm-7">
						 <textarea name="details" id="details"  title="Description"  required  class="form-control" rows="3"></textarea>                  
                      </div>
                    </div>
                    
                    <div class="form-group">
                      <label for="inputEmail3" class="col-sm-3 control-label"> Estimated Time (Hours)*</label>
                      <div class="col-sm-7">
                      		   <input type="number" min="0" name="estimated_time" id="estimated_time" class="form-control" required>                       
                      </div>
                    </div>
                   
                    <div class="form-group">
                      <label for="inputEmail3" class="col-sm-3 control-label"> Allot To *</label>
                      <div class="col-sm-7">
                      <select name="employee" id="employee" class="form-control">
                        <option value="">[Select Employee]</option>
						<?php 
							$employees = $user->getEmployeelist();
							while($row_emp = mysql_fetch_array($employees))
							{

								echo '<option value="'.$row_emp["id"].'">'.$row_emp["fname"].'&nbsp;'.$row_emp["lname"].'</option>';
						 ?>
                         	
                         <?php 
						 	}
						 ?>

                      </select>
                      		   
                      </div>
                    </div>


					<div class="form-group">
                      <label for="inputEmail3" class="col-sm-3 control-label"> Allote Date *</label>
                      <div class="col-sm-7">
                      		   <input type="date" name="alloted_date" id="alloted_date" class="form-control" required>                       
                      </div>
                    </div>
                    
                    <div class="form-group">
                      <label for="inputEmail3" class="col-sm-3 control-label"> Allote By *</label>
                      <div class="col-sm-7">
                   	   <?php echo $user->getFullname($_SESSION['UID']); ?>
                       <input type="hidden" name="alloted_by" id="alloted_by" class="form-control" value="<?php echo $_SESSION['UID']; ?>">
                      </div>
                    </div>

                    
                    <div class="form-group">
                      <label for="inputEmail3" class="col-sm-3 control-label"> Priority *</label>
                      <div class="col-sm-7">
                      <select name="priority" id="priority" class="form-control">
                        <option value="1">Low</option>
                        <option value="2">Medium</option>
                        <option value="3">Urgent</option>
                        <option value="4">High</option>
                      </select>
                      		   
                      </div>
                    </div>
                   
                    
                    <div class="form-group">
                      <label for="inputEmail3" class="col-sm-3 control-label"> Status</label>
                      <div class="col-sm-7">
                      <select name="status" id="status" class="form-control">
                        <option value="1">Pending</option>
                        <option value="2">Ongoing</option>
                        <option value="3">Testing</option>
                        <option value="4">Reveiw</option>
                        <option value="5">Closed</option>
                      </select>
                      		   
                      </div>
                    </div>
                    <!-- /.box-body -->
                  <div class="box-footer">
                    <button type="button" onClick="window.location='task.php'" class="btn btn-default">Close</button>
                    <button type="submit" class="btn btn-info pull-right">Save</button>
                  </div><!-- /.box-footer -->
                </form>
              </div>
              </div>
           <?php die();} ?>
            
            
            <?php if($_GET['op'] == 'edit' & $_GET['id'] != '' ){ ?>
            <div class="col-xs-6"  style="margin-left:25%">
              
              <div class="box box-info">
                <div class="box-header with-border">
                  <h3 class="box-title">Edit </h3>
                </div><!-- /.box-header -->
                <?php
					#retrieve values
					$obj->key['id'] = $_GET['id'];
					$obj->select();
				
                    #error display section
					$msg_edit_success ="";
					$msg_edit = "";
					if(!empty($_GET['edit_error_msg']))
					{
					
						if($_GET['edit_error_msg'] == 'empty')
						{
							$msg_edit = "Please enter all required fields!";
						}
						
						if($_GET['edit_error_msg'] == 'failed')
						{
							$msg_edit = "Failed to add the page!";
						}
						
						if($_GET['edit_error_msg'] == 'success')
						{
							$msg_edit_success = "Updated successfully!";
						}
						
						
					?>
                <?php if(!empty($msg_edit)){ ?><br>
        					<div align="center" style="color:#FF0000"><?php print $msg_edit; ?></div><br><?php } ?>
                    <?php if(!empty($msg_edit_success)){ ?><br><div align="center" style="color:#006633"><?php print $msg_edit_success; ?></div><br><?php } ?>

                   <?php } ?>

                <!-- form start -->
                <form class="form-horizontal" action="do.php" method="post" enctype="multipart/form-data">
                  
                   <div class="box-body">
                    
                    	<input type="hidden" name="op" id="op" value="edit">
                        <input type="hidden" name="id" id="id" value="<?php echo $obj->value['id']; ?>">
                       
                 
                   
                    <div class="form-group">
                      <label for="inputEmail3" class="col-sm-3 control-label"> Task Title *</label>
                      <div class="col-sm-7">
					          <input type="text" name="title" id="title" value="<?php echo $obj->value['title']; ?>" class="form-control" required>                       
                      </div>
                    </div>
                    
                     
                  
                    <div class="form-group">
                      <label for="inputEmail3" class="col-sm-3 control-label">Description *</label>
                      <div class="col-sm-7">
					       <textarea name="details" id="details"  title="Description"  required  class="form-control"><?php echo strip_tags($obj->value['details']); ?></textarea>                      </div>
                    </div>


                    <div class="form-group">
                      <label for="inputEmail3" class="col-sm-3 control-label">Estimated Time (Hours)*</label>
                      <div class="col-sm-7">
                      <input type="number" min="0" name="estimated_time" id="estimated_time" class="form-control" value="<?php echo $obj->value['estimated_time']; ?>" required>                       
                      </div>
                    </div>
                    
                    <div class="form-group">
                      <label for="inputEmail3" class="col-sm-3 control-label"> Alloted To *</label>
                      <div class="col-sm-7">
                      <select name="employee" id="employee" class="form-control">
                        <option value="" >[Select Employee]</option>
						<?php 
							$employees = $user->getEmployeelist();
							while($row_emp = mysql_fetch_array($employees))
							{
						 			if($obj->value['alloted_to'] == $row_emp["id"])
									{ 
										$selection =  'selected';
									}
									else
									{
										$selection =  "";
									}

									echo '<option value="'.$row_emp["id"].'" '.$selection.'>'.$row_emp["fname"].'&nbsp;'.$row_emp["lname"].'</option>';
						 ?>
                         			
                         	
                         <?php 
						 	}
						 ?>

                      </select>
                      		   
                      </div>
                    </div>
                    
                    
                    
					<div class="form-group">
                      <label for="inputEmail3" class="col-sm-3 control-label"> Allote Date *</label>
                      <div class="col-sm-7">
                   	  	<input type="date"  name="alloted_date" id="alloted_date" class="form-control" value="<?php echo $obj->value['alloted_date']; ?>" required>                      </div>
                    </div>
                    
                    <div class="form-group">
                      <label for="inputEmail3" class="col-sm-3 control-label"> Allote By *</label>
                      <div class="col-sm-7">
                   	   <?php echo empty($obj->value['alloted_by'])?"None":$user->getFullname($obj->value['alloted_by']); ?>
                       <input type="hidden" name="alloted_by" id="alloted_by" class="form-control" value="<?php echo $_SESSION['UID']; ?>">
                      </div>
                    </div>
                    
                     
                     <div class="form-group">
                      <label for="inputEmail3" class="col-sm-3 control-label"> Priority *</label>
                      <div class="col-sm-7">
                      <select name="priority" id="priority" class="form-control">
                        <option value="1" <?php echo ($obj->value['priority'] == 1)?"selected":""; ?> >Low</option>
                        <option value="2" <?php echo ($obj->value['priority'] == 2)?"selected":""; ?> >Medium</option>
                        <option value="3" <?php echo ($obj->value['priority'] == 3)?"selected":""; ?> >Urgent</option>
                        <option value="4" <?php echo ($obj->value['priority'] == 4)?"selected":""; ?> >High</option>
                      </select>
                      		   
                      </div>
                    </div>
                    
                     <div class="form-group">
                      <label for="inputEmail3" class="col-sm-3 control-label"> Status</label>
                      <div class="col-sm-7">
                      <select name="status" id="status" class="form-control">
                       <option value="1" <?php echo ($obj->value['status'] == 1)?"selected":""; ?>>Pending</option>
                       <option value="2" <?php echo ($obj->value['status'] == 2)?"selected":""; ?>>Ongoing</option>
                       <option value="3" <?php echo ($obj->value['status'] == 3)?"selected":""; ?>>Testing</option>
                       <option value="4" <?php echo ($obj->value['status'] == 4)?"selected":""; ?>>Reveiw</option>
                       <option value="5" <?php echo ($obj->value['status'] == 5)?"selected":""; ?>>Closed</option>
                      </select>
                      		   
                      </div>
                    </div>
                     
                   
                  </div><!-- /.box-body -->
                 
                 
                  <div class="box-footer">
                    <button type="button" onClick="window.location='task.php'" class="btn btn-default">Close</button>
                    <button type="submit" class="btn btn-info pull-right">Save</button>
                  </div><!-- /.box-footer -->
                </form>
              </div>
            </div>
         <?php } ?>           
            
            
          
            <div class="col-xs-12">
              
              <div class="box">
                <div class="box-header">
                  <h3 class="box-title">Tasks</h3> 
               <div align="right">
                 	 <a href="../task/task.php?op=new" title="Add new task">Add New+</a>
                  </div>
                  <?php if($msg_op != ""){ ?>
                      <div align="center">
                        <span style="color:#006633"><?php echo $msg_op; ?></span> 
                        <a href="task.php" title="Close Message">[X]</a> 
                      </div> 
				  <?php } ?>
                </div><!-- /.box-header -->
                <div class="box-body">
                  <table width="101%" class="table table-bordered table-striped" id="example1">
                    <thead>
                      <tr>
                        <th width="4%">NO.</th>
                        <th width="13%">Task Title </th>
                        <th width="18%">Description</th>
                        <th width="14%">Alloted To</th>
                        <th width="14%">Alloted By-On</th>
                        <th width="8%">Estmtd</th>
                        <th width="7%">Used </th>
                        <th width="7%">Priority</th>
                        <th width="7%">Status</th>
                        <th width="8%">Options</th>
                      </tr>
                    </thead>
                    <tbody>
                      
                      <?php
					  $obj->page['CONDITION'] 	= "1";
					  $obj->page['ORDER'] 		= " `time` DESC";
					  $obj->startPaging(10);
					  ?>
                      
                      <?php
					  $no=1;
					   while($no = $obj->nextRecord()){ 
					  ?>
					  
                      <tr>
                        <td align="center"><?php echo $no++; ?></td>
                        <td><?php echo ucfirst($obj->value['title']); ?></td>
                        <td><?php echo $obj->value['details']; ?></td>
                        <td>
						<?php 
						  if(empty($obj->value['alloted_to']))
						  {
						  	echo 'None';
						  }
						  else
						  {
						  	//echo $obj->value['alloted_to'];
							echo  $user->getFullname($obj->value['alloted_to']);
							
						  }
						 
						 ?>                        </td>
                        
                        <td><?php echo empty($obj->value['alloted_by'])?'None':$obj->value['alloted_by']; ?></td>
                        <td><?php echo empty($obj->value['estimated_time'])?"0":$obj->value['estimated_time']; ?>&nbsp;Hrs</td>
						<td><?php echo empty($obj->value['used_time'])?"0":$obj->value['used_time']; ?> Hrs</td>
                        <td>
                        	<?php
								if($obj->value['priority'] == 1) { echo "Low";}
								if($obj->value['priority'] == 2) { echo "Medium";}
								if($obj->value['priority'] == 3) { echo "Urgent";}
								if($obj->value['priority'] == 4) { echo "High";}
							?>						</td>
                       
                        <td>
                        	<?php
								if($obj->value['status'] == 1) { echo "Pending";}
								if($obj->value['status'] == 2) { echo "Ongoing";}
								if($obj->value['status'] == 3) { echo "Testing";}
								if($obj->value['status'] == 4) { echo "Reveiw";}
								if($obj->value['status'] == 5) { echo "Closed";}
							?>						</td>
                       
                        
                        <td>
                        &nbsp;&nbsp;<a href="task.php?op=edit&id=<?php echo $obj->value['id']; ?>"><i class="fa fa-fw fa-edit"></i> Edit</a><br>
                        
                        <a href="do.php?op=delete&id=<?php echo $obj->value['id']; ?>" onClick="return confirm('Are you sure to remove this?');">&nbsp;
                        <i class="fa fa-fw fa-trash"></i>Delete</a>                         </td>
                      </tr>
                     <?php } ?>
                    </tbody>
                    <tfoot>
                      <tr>
                        <th>NO.</th>
                        <th>Task Title </th>
                        <th>Description</th>
                        <th>Alloted To</th>
                        <th>Alloted By - On</th>
                        <th>Estmtd</th>
                        <th>Used </th>
                        <th>Priority</th>
                        <th>Status</th>
                        <th>Options</th>
                      </tr>
                    </tfoot>
                  </table>
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div><!-- /.col -->
          </div><!-- /.row -->
        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->
      
      <footer class="main-footer">
        <div class="pull-right hidden-xs">
          <b>Version</b> 1.0.0
        </div>
        <strong>Developed @Bruce Clay</strong>
      </footer>
      
      
      <!-- Add the sidebar's background. This div must be placed
           immediately after the control sidebar -->
  </div><!-- ./wrapper -->

   <!-- jQuery 2.1.4 -->
    <script src="../../plugins/jQuery/jQuery-2.1.4.min.js"></script>
    <!-- Bootstrap 3.3.4 -->
    <script src="../../bootstrap/js/bootstrap.min.js"></script>
    <!-- DataTables -->
    <script src="../../plugins/datatables/jquery.dataTables.min.js"></script>
    <script src="../../plugins/datatables/dataTables.bootstrap.min.js"></script>
    <!-- SlimScroll -->
    <script src="../../plugins/slimScroll/jquery.slimscroll.min.js"></script>
    <!-- FastClick -->
    <script src="../../plugins/fastclick/fastclick.min.js"></script>
    <!-- AdminLTE App -->
    <script src="../../dist/js/app.min.js"></script>
    <!-- AdminLTE for demo purposes -->
    <script src="../../dist/js/demo.js"></script>
    <!-- page script -->
    <script>
      $(function () {
        $("#example1").DataTable();
        $('#example2').DataTable({
          "paging": true,
          "lengthChange": false,
          "searching": false,
          "ordering": true,
          "info": true,
          "autoWidth": false
        });
      });
    </script>
    
  	
    
    <!-- CK Editor -->
   <script src="../../plugins/ckeditor/ckeditor.js"></script>
   <!-- plugins\ckeditor-->
   <!-- Bootstrap WYSIHTML5 -->
    <script src="../../plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js"></script>
    <script>
      $(function () {
        // Replace the <textarea id="editor1"> with a CKEditor
        // instance, using default configuration.
		//CKEDITOR.replace('details');
		//CKEDITOR.replace('brief');

        //bootstrap WYSIHTML5 - text editor
        //$(".textarea").wysihtml5();
      });
    </script>
    
   
    
  </body>
</html>
