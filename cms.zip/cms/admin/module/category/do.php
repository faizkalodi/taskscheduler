<?php
/**************************************************************************
 *  Code @cmsFaiz
 *  Developed by Faiz Kalodi
 *  Purpose: For all operations
 *  (c) All Rights Reserved 
 *  Last Updated on 10 April 2020
 *************************************************************************/
require_once('../../../config/application.php');

switch(strtolower((empty($_GET['op']) ? empty($_POST['op']) ? false : trim($_POST['op']) : trim($_GET['op'])))){
 
 	
	case 'category_add':
	/**
 	 * Add new 
 	 */
	$App->setup(true, 'user,category', false, 'category:new');
	$user = new user();
	$obj  = new category;
	#
	$obj->value['value'] 			= 	$_POST['name'];
	$obj->value['parent'] 			= 	$_POST['parent_id'];	
	$obj->value['time'] 			= 	date('Y-m-d H:i:s');
	
	
	$parentID = $_POST['parent_id'];
	$value = $_POST['name'];
	
	
	if(empty($_SESSION['UID']))
	{
		header("location:../../index.php?error_msg=auth");
	}
	else
	{
			if(empty($_POST['name']))
			{
				header("location:categories.php?op=new&&error_msg=empty");
			}
			else
			{
				if($obj->exists($parentID, $value))
				{
					header("location:categories.php?op=new&id=$parentID&error_msg=exist");
				}
				else if($obj->add($parentID, $value))
				{	
					header("location:categories.php?op=new&id=$parentID&error_msg=success");
				}
			
			}
			
	}	
	
  	break;
	
	
	
	case 'category_edit':
	/**
 	 * Edit 
 	 */
	$App->setup(true, 'user,category', false, 'category:new');
	$user = new user();
	$obj  = new category;
	#
	$id   = $_POST['id'];
	
	if(empty($_SESSION['UID']))
	{
		header("location:../../index.php?error_msg=auth");
	}
	else
	{
		if(empty($_POST['name']))
		{
			header("location:categories.php?op=edit&id=$id&edit_error_msg=empty");
		}
		else
		{
				#update data
				$obj->key['id'] = $_POST['id'];
				
				if($obj->select())
				{		
						$parent_id 						=	$obj->value['parent'];	
						$obj->value['value'] 			= 	$_POST['name'];
						$obj->value['time'] 			= 	date('Y-m-d H:i:s');
				}
				
				if($obj->exists($parent_id,$_POST['name']))
				{
					
					header("location:categories.php?op=edit&id=$parent_id&pid=$id&edit_error_msg=exist");
				}
				else
				{

					if($obj->update())
					{
						header("location:categories.php?op=edit&id=$parent_id&pid=$id&edit_error_msg=success");
					}
					else
					{
						header("location:categories.php?op=edit&id=$parent_id&pid=$id&edit_error_msg=failed");
					}
				}
		}
		
	}	
	
	
	
  	break;
	
	
	case 'delete':
	/**
 	 * Edit 
 	 */
	$App->setup(true, 'user,category', false, 'category:remove');
	$user = new user();
	$obj  = new category;
	#
	
	if(empty($_SESSION['UID']))
	{
		header("location:../../index.php?error_msg=auth");
	}
	else
	{
		#update data
		$id = $obj->key['id'] = $_GET['id'];
		
		if($id < 101 or in_array($id,$protectedCategories))
		{
			 header("location:categories.php");
		}
	
		else if($obj->remove($id))
		{
			header("location:categories.php?op=delete");
		}
		/*$obj->delete();
		header("location:categories.php?op=delete");*/
	}
  	break;
	
	

		
# 
}
exit;
?>
