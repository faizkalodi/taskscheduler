<?php
/************************************************************************
 *  Code @Guiddit.com, JLT DUBAI *  Purpose: Password recovery operation
 *  (c) All Rights Reserved Guiddit CMS v1.0
 *  Last Updated on 2013 August 23
 *************************************************************************/ 
require_once('../config/application.php');
$App->setup(true, "user", false, false);
$user  = new user;
#
$email = empty($_POST['email'])?"":$_POST['email'];
///$uname = empty($_POST['Username'])?"":$_POST['Username'];
#
if($user->userCheck($uname=false,$email))
{
 $uid = $user->userCheck($uname,$email);
 $nPass ='#Yq'.rand().'nR';
 if($user->resetPassword($uid,  $nPass))
   {
	$user->key['id'] = $uid;
    if($user->select())
	  {
      	/* Please edit here */
		$fname = 'Administrator';
		$femail = 'admin@guiddit.com';
		
	    $name  = $user->value['uname'];
	    $email = $email;
	    $uname = $user->value['uname'];
	    $pass  = $nPass; 
	    $sub   =  "Your Password for $App->name ";
     	#--
        $body    = "Dear {$name},<br />";
		$body   .= "<p>Your Password request  for Control Panel <b>{$App->name}</b> has been verified ,<br /></p>";  
	    $body   .= "<p><b>Username :{$uname}</b></p>";
	    $body   .= "<p><b>Password :{$pass}</b></p>";
	    $body   .= "<br />Thank You<br />";
	    #--- Prepare Headers for the Mail
		$_header  = "MIME-Version: 1.0\r\n";
		$_header .= "Content-type: text/html; charset=iso-8859-1\r\n";
		$_header .= "From:{$fname} <{$femail}>\r\n";
		$_header .= "Reply-To:{$fname}<{$femail}>\r\n";
		$_header .= "Return-Path:{$fname}\r\n";
		$_header .= "X-Mailer: PHP v".phpversion();
	   #--	
		 
		 //die($body);
		 
		 if(@mail($email, $sub, $body, $_header)){
           $App->message("Your Password has been sent to {$email}!", "Forget Password", false, 'javascript:window.close();', 'Close');
		  }else{
          $App->message("Sorry, Password Sending failed to {$email}!", "Forget Password", false, 'javascript:window.history.back();;', 'Back');
		  }
	  }
	  
	} else{
       $App->message("Sorry,Unexpected Error<br>Unable to rest the password  !", "Forgot Password?", false, 'javascript:window.history.back();', 'Back');
  }
	 
}else{
 $App->message("Sorry there are no users with this email", "Forgot Password?", false, 'javascript:window.history.back();', 'Back');
}
//-
echo '<?xml version="1.0" encoding="utf-8"?>';
?>
