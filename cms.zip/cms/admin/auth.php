<?php
/************************************************************************
 *  Code @cmsFaiz
 *  Developed by Faiz Kalodi
 *  Purpose: For all operations
 *  (c) All Rights Reserved 
 *  Last Updated on 10 April 2020
 *************************************************************************/
require_once('../config/application.php');

switch(strtolower((empty($_GET['op']) ? empty($_POST['op']) ? false : trim($_POST['op']) : trim($_GET['op'])))){
 
 	#User Login
	case 'uin': 
		
		
			$App->setUp(false,"user", false, NONE);
			$user 			= 	new	user;
			#
					
			if(!empty($_POST['username']) || !empty($_POST['password']))
			{
									
					if($user->signIn($_POST['username'], $_POST['password'], $webmaster = true))
					{
						/* Setting the remember me option */
						/* if($_POST['remember']== 1)
						  {
						  
							$expire=time()+60*60*24*30*12;
							setcookie("username", $_POST['username'], $expire);
							setcookie("password", $_POST['password'], $expire);
						  }	*/

						  header("location:module/dashboard/dashboard.php");
						  
					}
					else
					{	
						
						header("location:../admin/index.php?error_msg=invalid");
					}
				#			
			}
			else
			{
				
				header("location:../admin/index.php?error_msg=empty");
			}
			
		
		break;


	case 'signout':
		
		$App->setUp(false, "user", false, NONE);
		$user = new	user;
		$user->signOut();
 		header("location:../admin/index.php");
	break;	
	
	
	
	

		
# 
}
exit;
?>
