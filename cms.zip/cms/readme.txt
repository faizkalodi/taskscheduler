Simple Task scheduler
====================
Developed by Faiz
for developement used:  apache 2.2.8, php 5.26, mysql 5.0.5

If any problem fin in other versions, please follow above.